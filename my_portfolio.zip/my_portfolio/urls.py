from django.contrib import admin
from django.urls import path , include
from . import views
urlpatterns = [

path('',views.home, name='Home_Page'),
path('education/',views.education, name="education" ),
path('skills/',views.skills, name="skills" ),
path('interests/',views.interests, name="interests" ),
path('awards/',views.awards, name="awards" ),
path('projects/',views.projects, name="projects" ),
]

