from django.apps import AppConfig


class MyPortfolioConfig(AppConfig):
    name = 'my_portfolio'
